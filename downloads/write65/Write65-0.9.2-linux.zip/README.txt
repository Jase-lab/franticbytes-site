Write65 for Linux
=================

64-bit Intel or AMD. Needs glibc 2.35 or newer (Ubuntu 22.04 LTS,
Fedora 36+, Debian 12+). Not for ARM boards or Chromebooks.

1. Unzip this download to a folder you keep (not /tmp).
2. Make the AppImage executable, then run it:

     chmod +x Write65-x86_64.AppImage
     ./Write65-x86_64.AppImage

Or in the file manager: right-click the AppImage, Properties,
allow executing as a program, then double-click it.

If it fails with a FUSE / AppImage error:

     sudo apt install libfuse2

The first launch asks whether to create ~/Documents/Write65 as the
default folder. Y creates it. N opens a folder picker.
