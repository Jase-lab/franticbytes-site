Write65 for Windows
===================

64-bit Windows 10 or 11 (Intel or AMD).

1. Unzip this download to a folder you keep.
2. Double-click write65.exe.

Windows often blocks a program that came from the internet:

  - If you see "Windows protected your PC", click More info,
    then Run anyway.

  - Or right-click write65.exe, Properties. If Unblock appears
    at the bottom, tick it, then Apply and OK.

Windows Defender may quarantine a new .exe the first time.
Restore it from Virus & threat protection -> Protection history.

The first launch asks whether to create Documents\Write65 as the
default folder. Y creates it. N opens a folder picker.
