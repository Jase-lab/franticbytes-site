Write65 for Windows
===================

64-bit Windows 10 or 11 (Intel or AMD).

1. Unzip this download to a folder you keep.
2. Double-click write65.exe.

This build is not signed, so Windows often blocks it because it
came from the internet:

  - If you see "Windows protected your PC", click More info,
    then Run anyway.

  - Or right-click write65.exe, Properties. If Unblock appears
    at the bottom, tick it, then Apply and OK.

Windows Defender may quarantine a new .exe the first time.
Restore it from Virus & threat protection -> Protection history.

The first launch asks whether to create Documents\Write65 as the
default folder. Y creates it. N opens a folder picker.

MEGA65 transfer uses mega65_ftp, which Write65 unpacks itself into
%APPDATA%\write65\mega65-ftp\ the first time you Import or Export.
You do not need to install it by hand.
