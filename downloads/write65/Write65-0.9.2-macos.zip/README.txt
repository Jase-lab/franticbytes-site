Write65 for macOS
=================

1. Unzip this download.
2. Drag Write65.app to Applications, or leave it in this folder.
3. Double-click Write65.app.

This build is not signed or notarized, so macOS will refuse it.

  - Dismiss the first dialog.
  - Open System Settings -> Privacy & Security. Find the message
    that Write65 was blocked and click Open Anyway, then Open.

You can also right-click Write65.app, choose Open, then Open in
the dialog. That skips the Privacy page on some macOS versions.

If it is still blocked (typical after a browser download):

     xattr -cr /Applications/Write65.app

Use the real path if the app is not in Applications.

The first launch asks whether to create Documents/Write65 as the
default folder. Y creates it. N opens a folder picker.

On the Mac, editor shortcuts use Command (⌘) instead of Ctrl.
