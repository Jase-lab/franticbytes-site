Write65 for macOS
=================

This build is for Apple Silicon Macs (M1 or later) running
macOS 11 or later. It does not run on Intel Macs.

1. Unzip this download.
2. Drag Write65.app to Applications, or leave it in this folder.
3. Double-click Write65.app.

This build is not signed or notarized, so macOS will block it
the first time you open it.

  - Dismiss the first dialog.
  - Open System Settings -> Privacy & Security. Find the message
    that Write65 was blocked and click Open Anyway, then Open.

On macOS 14 and earlier, you can also right-click Write65.app,
choose Open, then Open in the dialog. That skips the Privacy page.

If it is still blocked (typical after a browser download):

     xattr -cr /Applications/Write65.app

Use the real path if the app is not in Applications.

The first launch asks whether to create Documents/Write65 as the
default folder. Y creates it. N opens a folder picker.

On the Mac, editor shortcuts use Command (⌘) instead of Ctrl.
